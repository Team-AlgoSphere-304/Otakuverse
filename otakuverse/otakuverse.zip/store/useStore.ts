import { create } from 'zustand';
import { User, RecommendationItem, HistoryItem } from '../types';
import { authService } from '../services/api';

interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (token: string, user: User) => void;
  logout: () => void;
  updateUser: (user: User) => void;
}

interface AppState {
  recommendations: RecommendationItem[];
  history: HistoryItem[];
  setRecommendations: (items: RecommendationItem[]) => void;
  setHistory: (items: HistoryItem[]) => void;
  addToHistory: (item: HistoryItem) => void;
}

export const useAuthStore = create<AuthState>((set) => {
  // Initialize from local storage
  const storedToken = localStorage.getItem('auth_token');
  const storedUser = localStorage.getItem('user_data');
  
  return {
    token: storedToken,
    user: storedUser ? JSON.parse(storedUser) : null,
    isAuthenticated: !!storedToken,
    isLoading: false,
    login: (token, user) => {
      localStorage.setItem('auth_token', token);
      localStorage.setItem('user_data', JSON.stringify(user));
      set({ token, user, isAuthenticated: true });
    },
    logout: () => {
      localStorage.removeItem('auth_token');
      localStorage.removeItem('user_data');
      set({ token: null, user: null, isAuthenticated: false });
    },
    updateUser: (user) => {
      localStorage.setItem('user_data', JSON.stringify(user));
      set({ user });
    }
  };
});

export const useAppStore = create<AppState>((set) => ({
  recommendations: [],
  history: [],
  setRecommendations: (items) => set({ recommendations: items }),
  setHistory: (items) => set({ history: items }),
  addToHistory: (item) => set((state) => ({ history: [item, ...state.history] })),
}));