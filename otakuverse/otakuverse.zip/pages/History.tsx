import React, { useEffect, useState } from 'react';
import { useAuthStore } from '../store/useStore';
import { recommendationService } from '../services/api';
import { HistoryItem, ContentType } from '../types';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend } from 'recharts';
import { CONTENT_TYPE_LABELS } from '../constants';
import { Clock, TrendingUp } from 'lucide-react';

const COLORS = ['#6366f1', '#a855f7', '#06b6d4', '#ec4899', '#f59e0b', '#10b981', '#ef4444', '#8b5cf6', '#64748b'];

const History: React.FC = () => {
  const { user } = useAuthStore();
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      recommendationService.getHistory(user.id)
        .then(setHistory)
        .catch(console.error)
        .finally(() => setLoading(false));
    }
  }, [user]);

  // Transform data for charts
  const typeDistribution = Object.values(ContentType).map(type => {
    const count = history.filter(h => h.content_type === type).length;
    return { name: CONTENT_TYPE_LABELS[type], value: count };
  }).filter(d => d.value > 0);

  // Mock data for rating distribution since real history items might not have it populated fully in this demo
  const ratingData = [1, 2, 3, 4, 5].map(rating => ({
    rating: `${rating} Stars`,
    count: history.filter(h => Math.round(h.rating) === rating).length
  }));

  if (loading) {
    return <div className="text-center py-20 text-slate-400">Loading history...</div>;
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-white">Consumption History</h1>
        <div className="bg-slate-800 px-4 py-2 rounded-lg border border-slate-700 text-slate-300">
          Total Items: <span className="font-bold text-white">{history.length}</span>
        </div>
      </div>

      {history.length > 0 ? (
        <>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-slate-800/50 p-6 rounded-2xl border border-slate-700">
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                <TrendingUp size={18} className="text-indigo-400" />
                Content Distribution
              </h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={typeDistribution}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {typeDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155', color: '#f8fafc' }}
                      itemStyle={{ color: '#f8fafc' }}
                    />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="bg-slate-800/50 p-6 rounded-2xl border border-slate-700">
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                <TrendingUp size={18} className="text-purple-400" />
                Rating Spread
              </h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={ratingData}>
                    <XAxis dataKey="rating" stroke="#94a3b8" fontSize={12} />
                    <YAxis stroke="#94a3b8" fontSize={12} />
                    <Tooltip 
                      cursor={{fill: 'transparent'}}
                      contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155', color: '#f8fafc' }}
                    />
                    <Bar dataKey="count" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          <div className="bg-slate-800/50 rounded-2xl border border-slate-700 overflow-hidden">
            <div className="p-4 border-b border-slate-700 bg-slate-800/80">
              <h3 className="font-semibold text-white flex items-center gap-2">
                <Clock size={18} className="text-cyan-400" />
                Recent Activity
              </h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left text-slate-400">
                <thead className="text-xs text-slate-300 uppercase bg-slate-800">
                  <tr>
                    <th className="px-6 py-3">Title</th>
                    <th className="px-6 py-3">Type</th>
                    <th className="px-6 py-3">Rating</th>
                    <th className="px-6 py-3">Date</th>
                  </tr>
                </thead>
                <tbody>
                  {history.map((item) => (
                    <tr key={item.id} className="border-b border-slate-700 hover:bg-slate-700/50">
                      <td className="px-6 py-4 font-medium text-white">{item.title}</td>
                      <td className="px-6 py-4">
                        <span className="px-2 py-1 bg-slate-700 rounded text-xs text-slate-300">
                          {CONTENT_TYPE_LABELS[item.content_type]}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-yellow-400 font-bold">{item.rating} ★</td>
                      <td className="px-6 py-4">{new Date(item.watched_at).toLocaleDateString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      ) : (
        <div className="text-center py-20 bg-slate-800/30 rounded-2xl border border-dashed border-slate-700">
          <p className="text-slate-500 mb-4">You haven't rated any content yet.</p>
          <a href="#/recommendations" className="text-indigo-400 hover:text-indigo-300">
            Start rating to build your history!
          </a>
        </div>
      )}
    </div>
  );
};

export default History;