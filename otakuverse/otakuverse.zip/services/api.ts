import axios from 'axios';
import { AuthResponse, HistoryItem, RateRequest, RecommendationItem, RecommendationRequest, User, ContentType } from '../types';

// Safely access env variables. In native ESM environments (like browser without bundler injection), import.meta.env might be undefined.
const env = (import.meta as any).env;
const API_URL = env?.VITE_API_URL || 'http://localhost:8000/api';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add auth token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('auth_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Mock delay helper
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const authService = {
  login: async (email: string, password: string): Promise<AuthResponse> => {
    // MOCK IMPLEMENTATION: Bypass backend
    console.log(`[Mock Auth] Logging in with ${email}`);
    await delay(1000); // Simulate network latency

    // Simulate basic validation or error if needed (optional)
    if (!email || !password) {
       throw { response: { data: { message: 'Email and password required' } } };
    }

    // Return mock successful response
    return {
      token: 'mock-jwt-token-' + Date.now(),
      user: {
        id: 'mock-user-123',
        username: email.split('@')[0],
        email: email,
        preferences: {
          favorite_genres: ['Action', 'Fantasy']
        }
      }
    };

    /* REAL BACKEND CALL - Uncomment to restore
    const response = await api.post<AuthResponse>('/auth/login', { email, password });
    return response.data;
    */
  },

  register: async (username: string, email: string, password: string): Promise<AuthResponse> => {
    // MOCK IMPLEMENTATION: Bypass backend
    console.log(`[Mock Auth] Registering ${username}`);
    await delay(1000);

    return {
      token: 'mock-jwt-token-' + Date.now(),
      user: {
        id: 'mock-user-' + Date.now(),
        username: username,
        email: email,
        preferences: {}
      }
    };

    /* REAL BACKEND CALL - Uncomment to restore
    const response = await api.post<AuthResponse>('/auth/register', { username, email, password });
    return response.data;
    */
  },

  getProfile: async (): Promise<User> => {
    // MOCK IMPLEMENTATION
    // Usually used to validate token on refresh, return mock user
    await delay(500);
    return {
      id: 'mock-user-123',
      username: 'MockUser',
      email: 'mock@example.com'
    };

    /* REAL BACKEND CALL - Uncomment to restore
    const response = await api.get<User>('/auth/profile');
    return response.data;
    */
  },
};

export const recommendationService = {
  getRecommendations: async (data: RecommendationRequest): Promise<RecommendationItem[]> => {
    try {
      const response = await api.post<RecommendationItem[]>('/recommendations/get', data);
      return response.data;
    } catch (error) {
      console.warn("Backend unreachable, returning mock recommendations for demo.");
      await delay(1500);
      return generateMockRecommendations(data.content_types[0]);
    }
  },
  rateRecommendation: async (data: RateRequest): Promise<void> => {
    try {
      await api.post('/recommendations/rate', data);
    } catch (error) {
      console.log("Mock rating submitted:", data);
      await delay(500);
    }
  },
  getHistory: async (userId: string): Promise<HistoryItem[]> => {
    try {
      const response = await api.get<HistoryItem[]>(`/recommendations/history/${userId}`);
      return response.data;
    } catch (error) {
      console.warn("Backend unreachable, returning mock history.");
      return [];
    }
  },
};

export const catalogService = {
  getAll: async (): Promise<RecommendationItem[]> => {
    try {
      const response = await api.get<RecommendationItem[]>('/catalog/all');
      return response.data;
    } catch (error) {
        console.warn("Backend unreachable, returning mock catalog.");
        return generateMockCatalog();
    }
  },
  getByType: async (type: ContentType): Promise<RecommendationItem[]> => {
    try {
      const response = await api.get<RecommendationItem[]>(`/catalog/${type}`);
      return response.data;
    } catch (error) {
        return generateMockCatalog().filter(i => i.content_type === type);
    }
  },
};

// Helper to determine which external score to show
function getExternalScores(type: ContentType) {
  const isMalType = [
    ContentType.ANIME, 
    ContentType.MANGA, 
    ContentType.MANHWA, 
    ContentType.LIGHT_NOVELS
  ].includes(type);

  const isImdbType = [
    ContentType.MOVIES, 
    ContentType.WEB_SERIES, 
    ContentType.GAMES // Sometimes games have imdb, but let's stick to this for now
  ].includes(type);

  return {
    mal_score: isMalType ? Number((Math.random() * (9.5 - 6.5) + 6.5).toFixed(2)) : undefined,
    imdb_score: isImdbType ? Number((Math.random() * (9.5 - 5.5) + 5.5).toFixed(1)) : undefined
  };
}

// Helper to generate mock data if backend is down (Ensures app is usable)
function generateMockRecommendations(type: ContentType): RecommendationItem[] {
  return Array.from({ length: 4 }).map((_, i) => {
    const scores = getExternalScores(type || ContentType.ANIME);
    return {
      id: `mock-${i}`,
      title: `Mock ${type || 'Title'} ${i + 1}`,
      content_type: type || ContentType.ANIME,
      genres: ['Action', 'Adventure', 'Mock Genre'],
      description: "This is a mock description generated because the backend is not connected. It simulates what a real recommendation would look like.",
      explanation: "This item was recommended based on your mock preferences. The AI (currently simulated) thinks you will like the combination of action and storytelling.",
      rating_score: 8.5 + (i * 0.2),
      mal_score: scores.mal_score,
      imdb_score: scores.imdb_score,
      cover_image: `https://picsum.photos/400/600?random=${i}`,
      user_rating: 0
    };
  });
}

function generateMockCatalog(): RecommendationItem[] {
    return Array.from({ length: 12 }).map((_, i) => {
        const type = Object.values(ContentType)[i % 9];
        const scores = getExternalScores(type);
        return {
            id: `catalog-${i}`,
            title: `Catalog Item ${i + 1}`,
            content_type: type,
            genres: ['Drama', 'Fantasy'],
            description: "Catalog item description placeholder.",
            explanation: "",
            rating_score: 7.0 + (i % 3),
            mal_score: scores.mal_score,
            imdb_score: scores.imdb_score,
            cover_image: `https://picsum.photos/400/600?random=${100+i}`
        };
    });
}

export default api;