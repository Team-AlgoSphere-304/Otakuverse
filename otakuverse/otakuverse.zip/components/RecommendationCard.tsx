import React, { useState, useEffect } from 'react';
import { RecommendationItem } from '../types';
import { CONTENT_TYPE_LABELS } from '../constants';
import { Star, Bookmark, Info, RotateCw, Check } from 'lucide-react';
import { recommendationService } from '../services/api';
import { useAuthStore } from '../store/useStore';

interface Props {
  item: RecommendationItem;
  onRate?: (id: string, rating: number) => void;
}

const RecommendationCard: React.FC<Props> = ({ item, onRate }) => {
  const [isFlipped, setIsFlipped] = useState(false);
  const [userRating, setUserRating] = useState<number>(item.user_rating || 0);
  const [ratingLoading, setRatingLoading] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const user = useAuthStore(state => state.user);

  useEffect(() => {
    if (item.user_rating) setUserRating(item.user_rating);
  }, [item.user_rating]);

  const handleRate = async (e: React.MouseEvent, rating: number) => {
    e.stopPropagation(); // Prevent card flip or other interactions
    if (!user) return;
    try {
      setRatingLoading(true);
      await recommendationService.rateRecommendation({
        user_id: user.id,
        item_id: item.id,
        rating: rating
      });
      setUserRating(rating);
      if (onRate) onRate(item.id, rating);
    } catch (e) {
      console.error(e);
    } finally {
      setRatingLoading(false);
    }
  };

  const handleSave = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsSaved(!isSaved);
  };

  const getBadgeColor = (type: string) => {
    switch (type) {
      case 'anime': return 'bg-pink-600 shadow-pink-500/20';
      case 'manga': return 'bg-orange-500 shadow-orange-500/20';
      case 'manhwa': return 'bg-yellow-600 shadow-yellow-500/20';
      case 'movies': return 'bg-red-600 shadow-red-500/20';
      case 'tv_shows': return 'bg-blue-600 shadow-blue-500/20';
      case 'games': return 'bg-purple-600 shadow-purple-500/20';
      case 'light_novels': return 'bg-emerald-600 shadow-emerald-500/20';
      default: return 'bg-indigo-600 shadow-indigo-500/20';
    }
  };

  return (
    <div className="group relative h-[460px] w-full perspective-1000">
      <div 
        className={`relative w-full h-full transition-all duration-700 transform-style-3d ${isFlipped ? 'rotate-y-180' : ''}`}
      >
        {/* Front Face */}
        <div className="absolute w-full h-full backface-hidden bg-slate-900 rounded-xl overflow-hidden shadow-2xl border border-slate-800 group-hover:border-indigo-500/50 transition-colors">
          
          {/* Image */}
          <div className="absolute inset-0">
            <img 
              src={item.cover_image || `https://picsum.photos/400/600?random=${item.id}`} 
              alt={item.title}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              onError={(e) => {
                (e.target as HTMLImageElement).src = `https://picsum.photos/400/600?random=${item.id}`;
              }}
            />
            {/* Gradients */}
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent opacity-80 group-hover:opacity-95 transition-opacity duration-300" />
          </div>

          {/* Top Labels */}
          <div className="absolute top-3 left-3 flex gap-2 z-10">
             <span className={`${getBadgeColor(item.content_type)} text-white text-[10px] font-bold px-2 py-1 rounded-full uppercase tracking-wider shadow-md`}>
                {CONTENT_TYPE_LABELS[item.content_type]}
             </span>
          </div>
          
          <div className="absolute top-3 right-3 z-10">
             <div className="bg-slate-950/70 backdrop-blur-md text-yellow-400 text-xs font-bold px-2 py-1 rounded-full flex items-center gap-1 border border-yellow-500/30">
               <Star size={12} fill="currentColor" />
               {item.rating_score}
             </div>
          </div>

          {/* Bottom Content Area */}
          <div className="absolute bottom-0 left-0 w-full p-4 z-20 flex flex-col justify-end">
            
            {/* Title & Info - Slides up on hover */}
            <div className="transform transition-transform duration-300 group-hover:-translate-y-1">
              <h3 className="text-xl font-bold text-white mb-2 leading-tight drop-shadow-md line-clamp-2">
                {item.title}
              </h3>
              
              <div className="flex flex-wrap gap-2 mb-1">
                {item.mal_score && (
                  <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-[#2e51a2] text-white">
                    MAL {item.mal_score}
                  </span>
                )}
                {!item.mal_score && item.imdb_score && (
                  <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-[#f5c518] text-black">
                    IMDb {item.imdb_score}
                  </span>
                )}
                {item.genres.slice(0, 2).map(g => (
                  <span key={g} className="text-[10px] text-slate-300 border border-slate-600/50 bg-slate-900/50 px-1.5 py-0.5 rounded backdrop-blur-sm">
                    {g}
                  </span>
                ))}
              </div>
            </div>

            {/* Hidden Content - Reveals on Hover */}
            <div className="grid grid-rows-[0fr] group-hover:grid-rows-[1fr] transition-all duration-300 ease-out">
              <div className="overflow-hidden">
                <div className="pt-3 flex flex-col gap-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-75">
                  
                  {/* Rating Section - Integrated into flow */}
                  <div className="bg-slate-900/80 backdrop-blur-md p-2.5 rounded-lg border border-slate-700/50">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-[10px] uppercase font-bold text-slate-400">Your Rating</span>
                      <span className="text-xs font-bold text-yellow-400">{userRating > 0 ? userRating : '-'} / 5</span>
                    </div>
                    <div className="flex justify-between px-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          disabled={ratingLoading}
                          onClick={(e) => handleRate(e, star)}
                          className={`focus:outline-none transition-all hover:scale-125 p-0.5 ${
                            userRating >= star ? 'text-yellow-400' : 'text-slate-600 hover:text-yellow-400/50'
                          }`}
                        >
                          <Star size={20} fill={userRating >= star ? "currentColor" : "none"} />
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-2">
                    <button 
                      onClick={(e) => { e.stopPropagation(); setIsFlipped(true); }}
                      className="flex-1 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold py-2.5 rounded-lg transition-colors flex items-center justify-center gap-1.5 shadow-lg"
                    >
                      <Info size={16} />
                      Why?
                    </button>
                    <button 
                      onClick={handleSave}
                      className={`flex-1 text-xs font-bold py-2.5 rounded-lg transition-colors flex items-center justify-center gap-1.5 shadow-lg border ${
                        isSaved 
                        ? 'bg-emerald-600 border-emerald-500 text-white' 
                        : 'bg-slate-800/80 border-slate-600 text-slate-200 hover:bg-slate-700 hover:border-slate-500 backdrop-blur-sm'
                      }`}
                    >
                      {isSaved ? <Check size={16} /> : <Bookmark size={16} />}
                      {isSaved ? 'Saved' : 'Watch Later'}
                    </button>
                  </div>

                </div>
              </div>
            </div>
            
          </div>
        </div>

        {/* Back Face - AI Insight Only */}
        <div className="absolute w-full h-full backface-hidden rotate-y-180 bg-slate-900 rounded-xl overflow-hidden shadow-2xl border border-slate-700 p-5 flex flex-col">
          <div className="flex justify-between items-start mb-4 border-b border-slate-800 pb-3">
            <h4 className="text-lg font-bold text-indigo-400 flex items-center gap-2">
              <Info size={18} />
              AI Analysis
            </h4>
            <button 
              onClick={(e) => { e.stopPropagation(); setIsFlipped(false); }}
              className="p-1 hover:bg-slate-800 rounded-full text-slate-400 hover:text-white"
            >
              <RotateCw size={16} />
            </button>
          </div>

          <div className="flex-grow overflow-y-auto custom-scrollbar">
            <div className="bg-indigo-900/20 border border-indigo-500/20 p-4 rounded-lg mb-4">
               <p className="text-slate-200 text-sm italic leading-relaxed">
                "{item.explanation || "Our multi-agent system matched this based on your preference for complex narratives and dark aesthetics."}"
              </p>
            </div>
            <div className="space-y-2">
               <h5 className="text-slate-500 text-[10px] font-bold uppercase">Synopsis</h5>
               <p className="text-slate-400 text-xs leading-relaxed">
                 {item.description}
               </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RecommendationCard;